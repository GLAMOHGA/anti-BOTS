#!/usr/bin/env python3
"""Telegram bots Cleaner — Clean rewrite.
No config persistence. Step-level retry. pystyle banner. Fast animation."""

import asyncio, os, sys, time, base64, shlex
from io import StringIO
from datetime import datetime, timezone, timedelta
from pathlib import Path
from collections import Counter

# --- Dependencies ---
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.prompt import Prompt, IntPrompt, Confirm
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
except ImportError:
    os.system(f"{sys.executable} -m pip install rich")
    from rich.console import Console
    from rich.panel import Panel
    from rich.prompt import Prompt, IntPrompt, Confirm
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn

import requests
from telethon import TelegramClient, events
from telethon.network.connection import ConnectionTcpFull
from telethon.tl.functions.channels import EditBannedRequest, GetAdminLogRequest
from telethon.tl.functions.auth import ExportLoginTokenRequest, ImportLoginTokenRequest
from telethon.tl.types import ChatBannedRights, ChannelParticipantAdmin, ChannelParticipantCreator
from telethon.tl.types import MessageActionChatAddUser, MessageActionChatJoinedByLink
from telethon.tl.types import MessageActionChatJoinedByRequest, MessageActionChatJoinedViaCommunity
from telethon.tl.types.auth import LoginToken, LoginTokenMigrateTo, LoginTokenSuccess
from telethon.errors import PhoneCodeInvalidError, PhoneCodeExpiredError, SessionPasswordNeededError
from telethon.errors import PasswordHashInvalidError, FloodWaitError, ApiIdInvalidError

import qrcode
from pystyle import Colors, Colorate, Center

# --- Constants ---
MSK = timezone(timedelta(hours=3))
UTC = timezone.utc
SCRIPT_DIR = Path(__file__).parent.resolve()
SESSION_FILE = str(SCRIPT_DIR / "session.session")
LOG_FILE = SCRIPT_DIR / "joins.jsonl"

console = Console()

BANNER_ART = '''
▄████████  ▄█          ▄████████    ▄████████    ▄████████      ▀█████████▄   ▄██████▄      ███        ▄████████ 
███    ███ ███         ███    ███   ███    ███   ███    ███        ███    ███ ███    ███ ▀█████████▄   ███    ███ 
███    █▀  ███         ███    █▀    ███    ███   ███    ███        ███    ███ ███    ███    ▀███▀▀██   ███    █▀  
███        ███        ▄███▄▄▄       ███    ███  ▄███▄▄▄▄██▀       ▄███▄▄▄██▀  ███    ███     ███   ▀   ███        
███        ███       ▀▀███▀▀▀     ▀███████████ ▀▀███▀▀▀▀▀        ▀▀███▀▀▀██▄  ███    ███     ███     ▀███████████ 
███    █▄  ███         ███    █▄    ███    ███ ▀███████████        ███    ██▄ ███    ███     ███              ███ 
███    ███ ███▌    ▄   ███    ███   ███    ███   ███    ███        ███    ███ ███    ███     ███        ▄█    ███ 
████████▀  █████▄▄██   ██████████   ███    █▀    ███    ███      ▄█████████▀   ▀██████▀     ▄████▀    ▄████████▀  
           ▀                                     ███    ███                                                        
'''


def clear():
    os.system("cls" if os.name == "nt" else "clear")


def animate(text, delay=0.0001, color=None):
    prefix = f"\x1b[{color}m" if color else ""
    suffix = "\x1b[0m" if color else ""
    for ch in text:
        sys.stdout.write(prefix + ch + suffix)
        sys.stdout.flush()
        time.sleep(delay)
    print()


def header(title, color="35"):
    try:
        w = os.get_terminal_size().columns
    except:
        w = 80
    s = f" {title} "
    each = max(4, (w - len(s)) // 2)
    line = "─" * each
    animate(f"{line}{s}{line}", delay=0.001, color=color)


def show_banner():
    clear()
    print(Center.XCenter(Colorate.Diagonal(Colors.white_to_red, BANNER_ART, 1)))
    print()
    try:
        print(Center.XCenter(Colorate.Horizontal(Colors.white_to_red, "работает в чате и в канале", 1)))
    except:
        animate("работает в чате и в канале", delay=0.0001, color="37")
    print()
    # Security warning panel
    console.print(Panel.fit(
        "[bold red]⚠  ВАЖНО  ⚠[/bold red]\n\n"
        "[bold]НИКОМУ НЕ ДАВАЙТЕ И НЕ ПОКАЗЫВАЙТЕ:[/bold]\n"
        "  • [cyan]api_id[/cyan]\n"
        "  • [cyan]api_hash[/cyan]\n"
        "  • файл [cyan]session.session[/cyan]\n\n"
        "Это твои приватные ключи. Любой, у кого они есть,\n"
        "может войти в твой Telegram-аккаунт под твоим именем.",
        title="🔒  БЕЗОПАСНОСТЬ", border_style="red"))
    print()
    # Info panel
    console.print(Panel.fit(
        "[bold cyan]Как всё работает[/bold cyan]\n\n"
        "Бот подключается к твоему Telegram-аккаунту\n"
        "и читает админ-лог чата за выбранное число дней.\n\n"
        "[yellow]Как бот находит накрутку:[/yellow]\n"
        "  Бот ищет минуту с аномально большим числом\n"
        "  вступлений, расширяет окно до падения активности\n"
        "  и показывает тебе. Ты выбираешь:\n"
        "  [cyan]забанить[/cyan] или [cyan]кикнуть[/cyan].\n\n"
        "[yellow]Важно:[/yellow]\n"
        "  • Ты сам должен быть админом в чате или канале\n"
        "  • Банит [bold]твой аккаунт[/bold] (не бот)\n"
        "  • Работает и в чате, и в канале",
        title="📖  Как это работает", border_style="blue"))
    print()


def retry_step(prompt="Нажми Enter чтобы попробовать снова..."):
    try:
        animate(prompt, delay=0.001, color="33")
        animate("либо нажми клавишу P чтобы начать все заново", delay=0.001, color="33")
        r = input()
        if r.strip().lower() == "p":
            raise KeyboardInterrupt("USER_PRESSED_P")
    except KeyboardInterrupt as e:
        if "USER_PRESSED_P" in str(e):
            raise  # Re-raise to trigger full restart
        pass


def vpn_hint():
    """Подсказка при сетевых ошибках."""
    animate("⚠  Возможно блокировка Telegram в твоей сети.", delay=0.001, color="33")
    animate("   Включи VPN и попробуй снова.", delay=0.001, color="33")
    animate("   Если VPN уже включен: удали логи из папки, в которой лежит clean.py", delay=0.001, color="33")
    animate("   (файлы session.session, .last_creds, joins.jsonl) и перезапусти скрипт.", delay=0.001, color="33")


def _make_msg_link(chat_entity, msg_id):
    """Generate a t.me link to a message in a channel/chat."""
    if not msg_id:
        return None
    username = getattr(chat_entity, 'username', None)
    if username:
        return f"https://t.me/{username}/{msg_id}"
    cid = getattr(chat_entity, 'id', 0)
    if cid:
        # Remove the -100 prefix for private channels
        clean_id = abs(cid) % 10000000000 if abs(cid) > 10000000000 else abs(cid)
        return f"https://t.me/c/{clean_id}/{msg_id}"
    return None


# ============================================================================
# Wizard — no config persistence, asks everything fresh every run
# ============================================================================
def wizard():
    clear()
    show_banner()

    console.print(Panel.fit(
        "[bold]Первый запуск — настроим бота[/bold]\n\n"
        "Что понадобится:\n"
        "  • [cyan]api_id[/cyan] и [cyan]api_hash[/cyan] с my.telegram.org\n"
        "  • Выбор способа входа (код или QR)",
        title="🧙  Установка", border_style="cyan"))
    print()

    # Шаг 1 — API credentials
    from rich.rule import Rule
    console.print(Rule("[bold]Шаг 1 из 2  —  API credentials[/bold]", style="cyan"))
    console.print("1. Открой my.telegram.org в браузере")
    console.print("2. Войди по телефону → API development tools")
    console.print("3. Создай приложение (любое имя, платформа = Other)")
    console.print("4. Скопируй api_id (число) и api_hash (строка)\n")
    api_id = IntPrompt.ask("[bold yellow]api_id[/bold yellow]")
    api_hash = Prompt.ask("[bold yellow]api_hash[/bold yellow]")
    print()

    # Шаг 2 — Login method
    console.print(Rule("[bold]Шаг 2 из 2  —  Вход в аккаунт[/bold]", style="cyan"))
    console.print("[bold]Зачем:[/bold] без этого скрипт не сможет прочитать")
    console.print("историю чата и забанить ботов.\n")
    console.print("[bold]Выбери способ входа:[/bold]")
    console.print("  [cyan]1[/cyan] — По коду (придёт в приложение Telegram или СМС).")
    console.print("  [cyan]2[/cyan] — По QR-коду (наведи камеру телефона, СМС не нужны).\n")
    method = Prompt.ask("[bold yellow]Твой выбор[/bold yellow]")
    login_method = "qr" if method.strip() == "2" else "code"

    phone = ""
    if login_method == "code":
        phone = Prompt.ask("[bold yellow]Номер телефона, с которого выполнен вход в my.telegram.org[/bold yellow] (пример +00000000000)")
    else:
        console.print("\n[dim]Вход без номера доступен по QR-коду.[/dim]")

    return {"api_id": api_id, "api_hash": api_hash, "phone": phone, "login_method": login_method}


# ============================================================================
# Login — code or QR
# ============================================================================
async def login(cfg):
    while True:
        try:
            client = TelegramClient(
    SESSION_FILE, 
    cfg["api_id"], 
    cfg["api_hash"], 
    connection=ConnectionTcpFull,
    connection_retries=10, 
    retry_delay=5, 
    timeout=30, 
    use_ipv6=False,
    system_version="4.16.30-vxCUSTOM",
    app_version="1.0.0",
    device_model="PC",
    system_lang_code="en",
    lang_code="en"
)
            await client.connect()

            if await client.is_user_authorized():
                me = await client.get_me()
                animate(f"Вошёл как {me.first_name} (@{me.username})", delay=0.001, color="32")
                return client, me

            if cfg["login_method"] == "qr":
                me = await qr_login(client, cfg)
                if me:
                    return client, me
            else:
                me = await code_login(client, cfg)
                if me:
                    return client, me

            retry_step("Вход не удался. Нажми Enter чтобы попробовать снова...")
        except Exception as e:
            animate(f"Ошибка входа: {e}", delay=0.001, color="31")
            et = str(e).lower()
            if "struct.error" in et or "api_id" in et or "invokewithlayerrequest" in et:
                # Баг кода/библиотеки (Python 3.13 + api_id) — это НЕ сетевая ошибка
                animate("[ОШИБКА КОДА] Проблема с api_id (баг Python 3.13). Проверьте настройки клиента.", delay=0.001, color="31")
            elif "connection" in et or "timeout" in et or "errno" in et:
                vpn_hint()
            retry_step()


async def code_login(client, cfg):
    phone = cfg["phone"]
    if not phone:
        animate("Нет номера телефона!", delay=0.001, color="31")
        return None

    animate(f"Отправляю код на {phone}...", delay=0.001, color="36")
    sent = await client.send_code_request(phone)
    animate(f"Код отправлен: в приложении Telegram", delay=0.001, color="36")

    while True:
        code = await asyncio.to_thread(input, "Введи код: ")
        code = code.strip()
        if not code:
            continue
        if code.lower() == "qr":
            return await qr_login(client, cfg)
        if not code.isdigit():
            animate("Код должен быть числом", delay=0.001, color="31")
            continue
        try:
            await client.sign_in(phone=phone, code=code, phone_code_hash=sent.phone_code_hash)
            me = await client.get_me()
            return me
        except PhoneCodeInvalidError:
            animate("Неверный код", delay=0.001, color="31")
        except PhoneCodeExpiredError:
            animate("Код устарел. Запрашиваю новый...", delay=0.001, color="31")
            sent = await client.send_code_request(phone)
        except SessionPasswordNeededError:
            console.print(Panel.fit("[bold yellow]2FA включена. Введи пароль от Telegram:[/bold yellow]", title="🔒 2FA", border_style="yellow"))
            while True:
                pw = await asyncio.to_thread(input, "Пароль: ")
                if not pw:
                    continue
                try:
                    await client.sign_in(password=pw)
                    return await client.get_me()
                except PasswordHashInvalidError:
                    animate("Неверный пароль", delay=0.001, color="31")
        except Exception as e:
            animate(f"Ошибка: {e}", delay=0.001, color="31")
            return None


def print_qr(url):
    qr = qrcode.QRCode(box_size=1, border=1)
    qr.add_data(url)
    qr.make(fit=True)
    buf = StringIO()
    qr.print_ascii(out=buf, invert=True)
    print(buf.getvalue())


async def qr_login(client, cfg):
    scanned = asyncio.Event()

    @client.on(events.Raw)
    async def h(u):
        if type(u).__name__ == "UpdateLoginToken":
            scanned.set()

    while True:
        try:
            result = await client(ExportLoginTokenRequest(api_id=cfg["api_id"], api_hash=cfg["api_hash"], except_ids=[]))
        except Exception as e:
            animate(f"Ошибка QR: {e}", delay=0.001, color="31")
            return None

        if not isinstance(result, LoginToken):
            if isinstance(result, LoginTokenSuccess):
                return await client.get_me()
            animate(f"Неожиданный ответ: {type(result).__name__}", delay=0.001, color="31")
            return None

        token_b64 = base64.urlsafe_b64encode(result.token).decode("ascii").rstrip("=")
        tg_url = f"tg://login?token={token_b64}"

        print()
        header("НОВЫЙ QR-КОД", "35")
        print()
        print_qr(tg_url)
        print()
        animate(f"Ссылка: {tg_url}", delay=0.001, color="33")
        print()
        animate("отсканируй киворкод с телеграм аккаунта на котором использавалься", delay=0.001, color="37")
        animate("номер чтобы получить api_id и api_hash.", delay=0.001, color="37")
        animate("либо открой эту ссылку в телеграм аккаунте с которого взят api_id и api_hash.", delay=0.001, color="37")
        print()
        animate("Жду сканирования... (30 сек)", delay=0.001, color="33")
        animate("нажми Enter чтобы остановить", delay=0.001, color="33")

        try:
            # Wait for scan OR user pressing Enter (whichever comes first)
            scan_task = asyncio.create_task(scanned.wait())
            enter_task = asyncio.create_task(asyncio.to_thread(input, ""))
            done, pending = await asyncio.wait(
                {scan_task, enter_task},
                timeout=30,
                return_when=asyncio.FIRST_COMPLETED
            )
            for t in pending:
                t.cancel()
            scanned.clear()
        except asyncio.TimeoutError:
            animate("QR истёк. Генерирую новый...", delay=0.001, color="33")
            continue

        animate("QR отсканирован! Подтверждаю...", delay=0.001, color="36")
        try:
            result = await client(ExportLoginTokenRequest(api_id=cfg["api_id"], api_hash=cfg["api_hash"], except_ids=[]))
        except SessionPasswordNeededError:
            console.print(Panel.fit("[bold yellow]2FA включена. Введи пароль:[/bold yellow]", title="🔒 2FA", border_style="yellow"))
            while True:
                pw = await asyncio.to_thread(input, "Пароль: ")
                if not pw:
                    continue
                try:
                    await client.sign_in(password=pw)
                    return await client.get_me()
                except PasswordHashInvalidError:
                    animate("Неверный пароль", delay=0.001, color="31")
        except Exception as e:
            animate(f"Ошибка подтверждения: {e}", delay=0.001, color="31")
            return None

        if isinstance(result, LoginTokenSuccess):
            return await client.get_me()
        if isinstance(result, LoginTokenMigrateTo):
            animate(f"Мигрирую на DC {result.dc_id}...", delay=0.001, color="36")
            await client._switch_dc(result.dc_id)
            r2 = await client(ImportLoginTokenRequest(token=result.token))
            if isinstance(r2, LoginTokenSuccess):
                return await client.get_me()
        animate("Не удалось подтвердить вход. Генерирую новый QR...", delay=0.001, color="33")


# ============================================================================
# Post-login: chat → admin check → days → scan → ban/kick → delete → done
# ============================================================================
async def resolve_chat(client, chat_arg):
    if chat_arg.lstrip("-").isdigit():
        chat_arg = int(chat_arg)
    return await client.get_entity(chat_arg)


async def check_admin(client, chat, my_id):
    try:
        r = await client.get_participant(chat, my_id)
        if isinstance(r.participant, (ChannelParticipantAdmin, ChannelParticipantCreator)):
            return True
    except:
        pass
    try:
        from telethon.tl.types import ChannelParticipantsAdmins
        async for u in client.iter_participants(chat, filter=ChannelParticipantsAdmins):
            if u.id == my_id:
                return True
    except:
        pass
    return False


async def ban_user(client, chat, uid):
    await client(EditBannedRequest(channel=chat, participant=uid,
        banned_rights=ChatBannedRights(view_messages=True, until_date=0)))

async def kick_user(client, chat, uid):
    await client(EditBannedRequest(channel=chat, participant=uid,
        banned_rights=ChatBannedRights(view_messages=True, until_date=int(time.time())+5)))


async def safe_action(client, chat, uid, action_type, label=""):
    """Бан/кик с защитой от лимитов Telegram (FloodWait) и таймером ожидания.
    Возвращает True при успехе, False при обычной ошибке."""
    while True:
        try:
            if action_type == "ban":
                await ban_user(client, chat, uid)
                print(f"[BAN] id={uid} {label}")
            else:
                await kick_user(client, chat, uid)
                print(f"[KICK] id={uid} {label}")
            return True
        except FloodWaitError as e:
            print(f"[WAIT] Лимит Telegram! Ждем {e.seconds} секунд...")
            for i in range(e.seconds, 0, -1):
                sys.stdout.write(f"\rОсталось: {i//60:02d}:{i%60:02d} ")
                sys.stdout.flush()
                await asyncio.sleep(1)
            print("\nПродолжаю...")
            # цикл продолжается — пробуем этого же юзера снова
        except Exception as e:
            print(f"[FAIL] id={uid} {label}: {e}")
            es = str(e).lower()
            if "connection" in es or "timeout" in es or "connect" in es:
                vpn_hint()
            await asyncio.sleep(1)
            return False


async def detect_surge(client, chat, days):
    joiners = []
    cutoff = datetime.now(UTC) - timedelta(days=days)
    scanned = 0

    # Вступления ищем ТОЛЬКО в Admin Log (по сообщениям не ищем)
    if True:
        try:
            from telethon.tl.functions.channels import GetAdminLogRequest
            from telethon.tl.types import (
                ChannelAdminLogEventsFilter,
                ChannelAdminLogEventActionParticipantJoin,
                ChannelAdminLogEventActionParticipantJoinByInvite,
                ChannelAdminLogEventActionParticipantJoinByRequest,
                ChannelAdminLogEventActionParticipantInvite,
            )
            animate("Ищу вступления в Admin Log...", delay=0.001, color="33")
            print()

            try:
                events_filter = ChannelAdminLogEventsFilter(join=True, invite=True)
            except TypeError:
                try:
                    events_filter = ChannelAdminLogEventsFilter(join=True)
                except TypeError:
                    events_filter = None

            with Progress(SpinnerColumn(style="cyan"),
                TextColumn("[bold cyan]Admin Log:[/bold cyan]"),
                BarColumn(bar_width=30, style="grey30", complete_style="bold magenta", finished_style="bold green"),
                TextColumn("[yellow]батч {task.fields[b]}/20 | вступлений: [green]{task.fields[j]}[/green]"),
                console=console, transient=False) as aprog:
                atask = aprog.add_task("alog", total=20, b=0, j=len(joiners))

                max_id = 0
                # ID пользователей, которые уже записаны в joiners.
                # Один юзер мог зайти/выйти/зайти снова, и Telegram присылает
                # несколько событий о входе — записываем каждого только ОДИН раз,
                # иначе общее число ботов завышается (1076 вместо 700).
                seen_uids = set()
                for _batch in range(20):
                    aprog.update(atask, b=_batch + 1, j=len(joiners))

                    result = await client(GetAdminLogRequest(
                        channel=chat,
                        q="",
                        events_filter=events_filter,
                        max_id=max_id,
                        min_id=0,
                        limit=1000,
                    ))

                    if not result.events:
                        aprog.update(atask, completed=20)
                        break

                    for event in result.events:
                        try:
                            ev_date = event.date
                            if isinstance(ev_date, datetime):
                                ev_dt = ev_date.replace(tzinfo=UTC) if ev_date.tzinfo is None else ev_date.astimezone(UTC)
                            else:
                                ev_dt = datetime.fromtimestamp(ev_date, tz=UTC)
                        except:
                            continue

                        if ev_dt < cutoff:
                            break

                        action = event.action

                        if isinstance(action, ChannelAdminLogEventActionParticipantJoin):
                            uid = event.user_id
                        elif isinstance(action, ChannelAdminLogEventActionParticipantJoinByInvite):
                            uid = event.user_id
                        elif isinstance(action, ChannelAdminLogEventActionParticipantJoinByRequest):
                            uid = event.user_id
                        elif isinstance(action, ChannelAdminLogEventActionParticipantInvite):
                            try:
                                uid = action.participant.user_id
                            except:
                                uid = None
                        else:
                            uid = None

                        if uid and uid not in seen_uids:
                            seen_uids.add(uid)
                            try:
                                e = await client.get_entity(uid)
                                joiners.append((ev_dt, uid, e.username, e.first_name, 0))
                            except:
                                joiners.append((ev_dt, uid, None, None, 0))
                            aprog.update(atask, j=len(joiners))

                    if result.events:
                        max_id = result.events[-1].id
                    else:
                        break

            animate(f"Admin Log: всего найдено {len(joiners)} вступлений/приглашений.", delay=0.001, color="37")
        except Exception as e:
            animate(f"Admin Log не сработал: {e}", delay=0.001, color="33")

    if not joiners:
        return None

    joiners.sort(key=lambda x: x[0])
    buckets = Counter()
    for ts, uid, _, _, _ in joiners:
        buckets[ts.replace(second=0, microsecond=0)] += 1

    # Порог «аномальной» минуты = 2 вступления и больше.
    # Так ловятся и короткие плотные пачки, и затяжные волны (3-4 минуты и дольше),
    # где заходит по 2-3 бота в минуту.
    cand_thr = 2

    def expand_window(peak_min):
        # Волна = строгая цепочка ПОДРЯД идущих аномальных минут.
        # Любая минута ниже порога = конец волны (никаких пауз-«мостов»).
        s_start = peak_min
        s_end = peak_min

        cur = peak_min - timedelta(minutes=1)
        while cur in buckets and buckets[cur] >= cand_thr:
            s_start = cur
            cur -= timedelta(minutes=1)
            if (peak_min - cur).total_seconds() > 3600: break

        cur = peak_min + timedelta(minutes=1)
        while cur in buckets and buckets[cur] >= cand_thr:
            s_end = cur
            cur += timedelta(minutes=1)
            if (cur - peak_min).total_seconds() > 3600: break

        return s_start, s_end

    # Все минуты с аномальной активностью — кандидаты в волны
    candidates = sorted(m for m, c in buckets.items() if c >= cand_thr)
    if not candidates:
        return None

    used_minutes = set()
    waves = []
    for peak_min in candidates:
        if peak_min in used_minutes:
            continue
        s_start, s_end = expand_window(peak_min)

        # Пик волны — самая загруженная минута внутри окна
        wave_peak = 0
        m = s_start
        while m <= s_end:
            if m in buckets:
                used_minutes.add(m)
                wave_peak = max(wave_peak, buckets[m])
            m += timedelta(minutes=1)

        # Собираем вступивших в этой волне
        seen = set()
        sj = []
        for ts, uid, un, fn, mid in joiners:
            mm = ts.replace(second=0, microsecond=0)
            if s_start <= mm <= s_end and uid not in seen:
                seen.add(uid)
                sj.append({"user_id": uid, "username": un, "first_name": fn or "?",
                           "msg_id": mid,
                           "when_msk": ts.astimezone(MSK).strftime("%Y-%m-%d %H:%M")})

        # Ищем ссылку на начало волны: service-сообщение о вступлении
        # одного из ботов волны (админ-лог ID сообщений не содержит)
        first_link = None
        if sj:
            try:
                wids = {j["user_id"] for j in sj}
                offset = s_end + timedelta(minutes=1)
                checked = 0
                async for msg in client.iter_messages(chat, offset_date=offset):
                    try:
                        dt = msg.date
                        if isinstance(dt, datetime):
                            dt = dt.replace(tzinfo=UTC) if dt.tzinfo is None else dt.astimezone(UTC)
                        else:
                            dt = datetime.fromtimestamp(dt, tz=UTC)
                    except:
                        continue
                    if dt < s_start - timedelta(minutes=1):
                        break
                    checked += 1
                    if checked > 300:
                        break
                    a = msg.action
                    if a is None:
                        continue
                    hit = False
                    if isinstance(a, (MessageActionChatJoinedByLink, MessageActionChatJoinedByRequest, MessageActionChatJoinedViaCommunity)):
                        hit = msg.sender_id in wids
                    elif isinstance(a, MessageActionChatAddUser):
                        hit = any(u in wids for u in a.users)
                    if hit:
                        first_link = _make_msg_link(chat, msg.id)
                        break
            except Exception:
                pass

        waves.append({"surge_start": s_start.astimezone(MSK).strftime("%Y-%m-%d %H:%M"),
                      "surge_end": (s_end + timedelta(minutes=1)).astimezone(MSK).strftime("%Y-%m-%d %H:%M"),
                      "total": len(sj), "peak": wave_peak, "joiners": sj,
                      "first_msg_link": first_link})

    if not waves:
        return None

    waves.sort(key=lambda w: w["surge_start"])
    total = sum(len(w["joiners"]) for w in waves)

    return {"waves": waves, "total": total, "scanned": scanned,
            "chat_id": getattr(chat, 'id', 0)}


# ============================================================================
# Main flow with step-level retry
# ============================================================================
async def main_async():
    # --- BANNER ---
    show_banner()

    # --- AUTO-LOGIN: if session exists, skip wizard ---
    if os.path.exists(SESSION_FILE):
        # Try auto-login first
        header("АВТО ВХОД", "35")
        animate("Найдена сохранённая сессия. Пробую автологин...", delay=0.001, color="37")
        print()
        # We need api_id/api_hash from last run — try to read from a temp file
        creds_file = SCRIPT_DIR / ".last_creds"
        if creds_file.exists():
            import json
            try:
                saved = json.loads(creds_file.read_text(encoding="utf-8"))
                api_id = saved.get("api_id")
                api_hash = saved.get("api_hash")
                if api_id and api_hash:
                    client = TelegramClient(SESSION_FILE, api_id, api_hash, connection_retries=2, retry_delay=1)
                    await client.connect()
                    if await client.is_user_authorized():
                        me = await client.get_me()
                        animate("Автоматический вход выполнен!", delay=0.001, color="32")
                        animate(f"Аккаунт: {me.first_name} (@{me.username})", delay=0.001, color="37")
                        print()
                        # Menu after auto-login
                        header("ДАЛЬШЕ", "35")
                        animate("1. Продолжить с автологином", delay=0.001, color="37")
                        animate("2. Удалить файл с данными для автологина и начать всё заново", delay=0.001, color="37")
                        animate("3. Выйти", delay=0.001, color="37")
                        print()
                        ac = await asyncio.to_thread(input, "Твой выбор: ")
                        if ac.strip() == "2":
                            await client.disconnect()
                            try:
                                if os.path.exists(SESSION_FILE): os.remove(SESSION_FILE)
                                cf = SCRIPT_DIR / ".last_creds"
                                if cf.exists(): cf.unlink()
                            except: pass
                            animate("Файлы удалены. Перезапускаю...", delay=0.001, color="33")
                            await main_async()
                            return
                        elif ac.strip() == "3":
                            await client.disconnect()
                            return
                        # Option 1: continue to post-login
                        await _post_login(client, me)
                        return
                    await client.disconnect()
            except Exception as e:
                animate(f"Автологин не удался: {e}", delay=0.001, color="31")
                animate("Запускаю wizard...", delay=0.001, color="33")
                print()
        else:
            animate("Файл с данными для автологина не найден. Запускаю wizard...", delay=0.001, color="33")
            print()

    # --- WIZARD (no config persistence) ---
    while True:
        try:
            cfg = wizard()
            # Save api_id/api_hash for future auto-login
            import json
            creds_file = SCRIPT_DIR / ".last_creds"
            creds_file.write_text(json.dumps({"api_id": cfg["api_id"], "api_hash": cfg["api_hash"]}), encoding="utf-8")
            break
        except Exception as e:
            animate(f"Ошибка: {e}", delay=0.001, color="31")
            retry_step()

    # --- LOGIN ---
    while True:
        try:
            client, me = await login(cfg)
            if client:
                break
            retry_step()
        except Exception as e:
            animate(f"Ошибка: {e}", delay=0.001, color="31")
            retry_step()

    # --- LOGIN SUCCESS ---
    header("ВХОД ВЫПОЛНЕН", "35")
    animate("=== Аккаунт успешно войдён ===", delay=0.001, color="37")
    animate(f"Аккаунт: {me.first_name} (@{me.username})", delay=0.001, color="37")
    print()

    await _post_login(client, me)


async def _post_login(client, me):
    """Post-login flow: chat → admin → days → scan → ban/kick → delete → done"""

    # --- CHAT SELECTION ---
    while True:
        try:
            header("ВЫБОР ЧАТА", "35")
            animate("Чат, который нужно очистить от накрутки.", delay=0.0001, color="37")
            animate("Публичный — @username. Приватный — числовой ID.", delay=0.0001, color="37")
            print()
            chat_input = await asyncio.to_thread(input, "Chat @username или ID: ")
            if not chat_input.strip():
                continue
            chat_entity = await resolve_chat(client, chat_input)
            chat_title = getattr(chat_entity, "title", None) or getattr(chat_entity, "first_name", "?")
            # Detect if this is a channel or chat
            is_channel = (hasattr(chat_entity, 'broadcast') and chat_entity.broadcast) or \
                         (hasattr(chat_entity, 'megagroup') and not chat_entity.megagroup)
            chat_type_nom = "канал" if is_channel else "чат"
            chat_type_prep = "канале" if is_channel else "чате"
            animate(f"{chat_title} — это {chat_type_nom}", delay=0.001, color="37")
            print()
            break
        except Exception as e:
            animate(f"Ошибка: {e}", delay=0.001, color="31")
            vpn_hint()
            retry_step()

    # --- ADMIN CHECK (если не админ — назад к выбору чата) ---
    chat_ready = False
    while not chat_ready:
        try:
            header("ПРОВЕРКА НА АДМИНА", "35")
            if await check_admin(client, chat_entity, me.id):
                animate(f"OK Ты — админ в {chat_type_prep} {chat_title}", delay=0.001, color="37")
                print()
                chat_ready = True
            else:
                animate(f"Ты НЕ админ в {chat_type_prep} {chat_title}.", delay=0.001, color="31")
                animate("Возвращаюсь к выбору чата...", delay=0.001, color="31")
                print()
                while True:
                    try:
                        header("ВЫБОР ЧАТА", "35")
                        animate("Чат, который нужно очистить от накрутки.", delay=0.0001, color="37")
                        animate("Публичный — @username. Приватный — числовой ID.", delay=0.0001, color="37")
                        print()
                        chat_input = await asyncio.to_thread(input, "Chat @username или ID: ")
                        if not chat_input.strip():
                            continue
                        chat_entity = await resolve_chat(client, chat_input)
                        chat_title = getattr(chat_entity, "title", None) or getattr(chat_entity, "first_name", "?")
                        is_channel = (hasattr(chat_entity, 'broadcast') and chat_entity.broadcast) or \
                                     (hasattr(chat_entity, 'megagroup') and not chat_entity.megagroup)
                        chat_type_nom = "канал" if is_channel else "чат"
                        chat_type_prep = "канале" if is_channel else "чате"
                        animate(f"{chat_title} — это {chat_type_nom}", delay=0.001, color="37")
                        print()
                        break
                    except Exception as e:
                        animate(f"Ошибка: {e}", delay=0.001, color="31")
                        vpn_hint()
                        retry_step()
        except Exception as e:
            animate(f"Ошибка: {e}", delay=0.001, color="31")
            retry_step()

    # --- DAYS ---
    while True:
        try:
            header("ЗА СКОЛЬКО ДНЕЙ ИСКАТЬ НАКРУТКУ", "35")
            animate("Если боты зашли сегодня — пиши 1.", delay=0.0001, color="37")
            animate("Если боты зашли вчера — пиши 2.", delay=0.0001, color="37")
            animate("Если боты зашли 5 дней назад — пиши 5.", delay=0.0001, color="37")
            animate("Если не знаешь — пиши 7 (проверит последнюю неделю).", delay=0.0001, color="37")
            print()
            d = await asyncio.to_thread(input, "Введи число дней: ")
            days = int(d.strip())
            if days < 1: days = 1
            if days > 90: days = 90
            break
        except Exception as e:
            animate(f"Ошибка: {e}", delay=0.001, color="31")
            retry_step()
    print()

    # --- READY TO SCAN ---
    header("ВСЕ ПРОВЕРЕНО", "35")
    animate("Все на месте. Готов к сканированию.", delay=0.001, color="37")
    animate(f"Чат: {chat_title}", delay=0.001, color="37")
    animate(f"Окно скана: {days} дней", delay=0.001, color="37")
    print()
    animate("Как скрипт находит накрутку:", delay=0.001, color="37")
    animate("  Скрипт читает админ-лог чата и ищет в нём записи о вступлении", delay=0.001, color="37")
    animate("  (кто зашёл, кого пригласили, кто зашёл по ссылке или заявке).", delay=0.001, color="37")
    animate("  Если за одну минуту таких записей слишком много", delay=0.001, color="37")
    animate("  (например, 20 штук вместо обычных 1-2), скрипт понимает — это накрутка.", delay=0.001, color="37")
    print()
    try:
        animate(f"Нажми Enter чтобы отсканировать чат за {days} дн...", delay=0.001, color="33")
        input()
    except:
        pass
    print()

    # --- SCAN LOOP (simple — no crash) ---
    while True:
        # Scan
        header("СКАННИРОВАНИЕ", "35")
        try:
            surge = await detect_surge(client, chat_entity, days)
        except Exception as e:
            animate(f"Ошибка сканирования: {e}", delay=0.001, color="31")
            retry_step()
            continue

        if surge is not None:
            break  # Found surge — proceed to ban/kick

        # Surge not found — offer options
        animate("Наплыв не найден.", delay=0.001, color="37")
        animate(f"За {days} дней не было необычной активности вступлений.", delay=0.001, color="37")
        print()
        animate("1. Отсканировать ещё раз (другое количество дней)", delay=0.001, color="37")
        animate("2. Выбрать другой чат", delay=0.001, color="37")
        animate("3. Начать всё заново", delay=0.001, color="37")
        print()
        nc = await asyncio.to_thread(input, "Твой выбор: ")

        if nc.strip() == "1":
            # Re-ask days, then loop back to scan (continue)
            while True:
                try:
                    header("ЗА СКОЛЬКО ДНЕЙ ИСКАТЬ НАКРУТКУ", "35")
                    animate("Если боты зашли сегодня — пиши 1.", delay=0.0001, color="37")
                    animate("Если боты зашли вчера — пиши 2.", delay=0.0001, color="37")
                    animate("Если боты зашли 5 дней назад — пиши 5.", delay=0.0001, color="37")
                    animate("Если не знаешь — пиши 7.", delay=0.0001, color="37")
                    print()
                    d = await asyncio.to_thread(input, "Введи число дней: ")
                    days = int(d.strip())
                    if days < 1: days = 1
                    if days > 90: days = 90
                    break
                except Exception as e:
                    animate(f"Ошибка: {e}", delay=0.001, color="31")
                    retry_step()
            print()
            continue  # Loop back to top — re-scan

        elif nc.strip() == "2":
            # Re-ask chat + days, then loop back to scan (continue)
            while True:
                try:
                    header("ВЫБОР ЧАТА", "35")
                    animate("Чат, который нужно очистить.", delay=0.0001, color="37")
                    animate("Публичный — @username. Приватный — числовой ID.", delay=0.0001, color="37")
                    print()
                    chat_input = await asyncio.to_thread(input, "Chat @username или ID: ")
                    if not chat_input.strip():
                        continue
                    chat_entity = await resolve_chat(client, chat_input)
                    chat_title = getattr(chat_entity, "title", None) or getattr(chat_entity, "first_name", "?")
                    is_channel = (hasattr(chat_entity, 'broadcast') and chat_entity.broadcast) or \
                                 (hasattr(chat_entity, 'megagroup') and not chat_entity.megagroup)
                    chat_type_nom = "канал" if is_channel else "чат"
                    chat_type_prep = "канале" if is_channel else "чате"
                    animate(f"{chat_title} — это {chat_type_nom}", delay=0.001, color="37")
                    print()
                    if not await check_admin(client, chat_entity, me.id):
                        animate("Нет прав админа.", delay=0.001, color="31")
                        continue
                    animate(f"OK Ты — админ в {chat_type_prep} {chat_title}", delay=0.001, color="37")
                    print()
                    break
                except Exception as e:
                    animate(f"Ошибка: {e}", delay=0.001, color="31")
                    retry_step()
            # Re-ask days
            while True:
                try:
                    header("ЗА СКОЛЬКО ДНЕЙ ИСКАТЬ НАКРУТКУ", "35")
                    animate("Если боты зашли сегодня — пиши 1.", delay=0.0001, color="37")
                    animate("Если боты зашли вчера — пиши 2.", delay=0.0001, color="37")
                    animate("Если боты зашли 5 дней назад — пиши 5.", delay=0.0001, color="37")
                    animate("Если не знаешь — пиши 7.", delay=0.0001, color="37")
                    print()
                    d = await asyncio.to_thread(input, "Введи число дней: ")
                    days = int(d.strip())
                    if days < 1: days = 1
                    if days > 90: days = 90
                    break
                except Exception as e:
                    animate(f"Ошибка: {e}", delay=0.001, color="31")
                    retry_step()
            print()
            continue  # Loop back to top — re-scan with new chat + days

        else:
            # Start everything from scratch
            try: await client.disconnect()
            except: pass
            await main_async()
            return

    header("НАПЛЫВ НАЙДЕН", "35")
    animate(f"Всего найдено ботов за все волны: {surge['total']}", delay=0.001, color="37")
    animate(f"Найдено волн: {len(surge['waves'])}", delay=0.001, color="37")
    print()
    for i, w in enumerate(surge["waves"], 1):
        header(f"ВОЛНА {i}", "35")
        animate(f"Количество ботов: {w['total']}", delay=0.001, color="37")
        animate(f"Зашли с: {w['surge_start']} MSK", delay=0.001, color="37")
        animate(f"До: {w['surge_end']} MSK", delay=0.001, color="37")
        animate(f"Пик: {w['peak']} вступлений за минуту", delay=0.001, color="37")
        if w.get('first_msg_link'):
            animate(f"Ссылка на начало накрутки: {w['first_msg_link']}", delay=0.001, color="33")
        print()

    # --- ПРОВЕРКА СТАТУСА УЧАСТНИКОВ ---
    header("ПРОВЕРКА СТАТУСА", "35")
    animate("Проверяю статусы найденных ботов (забанен / не забанен)...", delay=0.001, color="37")
    animate("Это занимает пару секунд, скрипт работает. Подожди...", delay=0.001, color="37")
    print()
    all_joiners = {}
    for w in surge["waves"]:
        for j in w["joiners"]:
            all_joiners.setdefault(j["user_id"], j)
    all_ids = list(all_joiners.keys())
    ban_set = set()
    try:
        from telethon.tl.types import ChannelParticipantsBanned
        async for u in client.iter_participants(chat_entity, filter=ChannelParticipantsBanned):
            ban_set.add(u.id)
    except Exception as e:
        animate(f"Не удалось получить статус: {e}", delay=0.001, color="31")

    fresh = [uid for uid in all_ids if uid not in ban_set]
    print()

    # --- ACTION ---
    header("ЧТО ДЕЛАТЬ", "35")
    animate("1. Забанить всех ботов", delay=0.001, color="37")
    animate("2. Кикнуть всех ботов", delay=0.001, color="37")
    animate("3. Забанить только не забаненных", delay=0.001, color="37")
    animate("4. Ничего", delay=0.001, color="37")
    print()
    while True:
        choice = (await asyncio.to_thread(input, "Твой выбор: ")).strip()
        if choice in ["1", "2", "3", "4"]:
            break
        print("\x1b[31mНеверный выбор. Введи 1, 2, 3 или 4.\x1b[0m")
    print()

    action = None
    targets = []
    if choice == "1":
        action = "ban"; targets = all_ids
    elif choice == "2":
        action = "kick"; targets = all_ids
    elif choice == "3":
        action = "ban"; targets = fresh

    if choice == "3" and not targets:
        animate("Забаненых нет — все уже обработаны.", delay=0.001, color="33")
        print()
        animate("1. Начать заново", delay=0.001, color="37")
        animate("2. Выйти", delay=0.001, color="37")
        r = (await asyncio.to_thread(input, "Твой выбор: ")).strip()
        try: await client.disconnect()
        except: pass
        if r == "1":
            await main_async()
        return

    if action and targets:
        ok = 0; fail = 0
        for uid in targets:
            j = all_joiners.get(uid)
            un = f"@{j['username']}" if j and j.get("username") else "(no_username)"
            nm = j.get("first_name", "?") if j else "?"
            wn = j.get("when_msk", "?") if j else "?"
            label = f"{un} {nm} (joined {wn})"
            success = await safe_action(client, chat_entity, uid, action, label)
            if success:
                ok += 1
            else:
                fail += 1
            await asyncio.sleep(0.2)
        print()
        v = "Забанено" if action == "ban" else "Кикнуто"
        animate(f"=== {v} {ok}. Не удалось: {fail} ===", delay=0.001, color="37")
        print()

    # --- DELETE JOIN MESSAGES ---
    header("УДАЛИТЬ СООБЩЕНИЯ О ВСТУПЛЕНИИ", "35")
    animate("Удалить ли сообщения о вступлении ботов из чата?", delay=0.001, color="37")
    animate("1. Да", delay=0.001, color="37")
    animate("2. Нет", delay=0.001, color="37")
    print()
    while True:
        dc = (await asyncio.to_thread(input, "Твой выбор: ")).strip()
        if dc in ["1", "2"]:
            break
        print("\x1b[31mНеверный выбор. Введи 1 или 2.\x1b[0m")
    if dc == "1":
        header("УДАЛЯЮ", "35")
        del_count = 0
        try:
            banned_ids = set(all_joiners.keys())
            msgs = []
            end_utc = datetime.now(UTC) + timedelta(days=1)
            cutoff = datetime.now(UTC) - timedelta(days=days)
            async for msg in client.iter_messages(chat_entity, offset_date=end_utc):
                try:
                    dt = msg.date
                    if isinstance(dt, datetime):
                        dt = dt.replace(tzinfo=UTC) if dt.tzinfo is None else dt.astimezone(UTC)
                    else:
                        dt = datetime.fromtimestamp(dt, tz=UTC)
                except:
                    continue
                if dt < cutoff:
                    break
                a = msg.action
                if a is None:
                    continue
                match = False
                if isinstance(a, (MessageActionChatJoinedByLink, MessageActionChatJoinedByRequest, MessageActionChatJoinedViaCommunity)):
                    if msg.sender_id and msg.sender_id in banned_ids:
                        match = True
                elif isinstance(a, MessageActionChatAddUser):
                    if any(uid in banned_ids for uid in a.users):
                        match = True
                if match:
                    msgs.append(msg.id)
            if msgs:
                for i in range(0, len(msgs), 100):
                    batch = msgs[i:i+100]
                    await client.delete_messages(chat_entity, batch)
                    del_count += len(batch)
                animate(f"Удалено {del_count} service-сообщений.", delay=0.001, color="37")
            else:
                animate("Не найдено service-сообщений.", delay=0.001, color="37")
        except Exception as e:
            animate(f"Ошибка: {e}", delay=0.001, color="31")
        print()

    # --- THANK YOU ---
    header("ГОТОВО", "35")
    animate("=== Все успешно выполнено ===", delay=0.001, color="37")
    animate(f"Аккаунт: {me.first_name} (@{me.username})", delay=0.001, color="37")
    animate(f"Чат: {chat_title}", delay=0.001, color="37")
    print()
    header("СПАСИБО", "35")
    print()
    animate("привет спасибо что пользуешься этим скриптом/ботом.", delay=0.001, color="37")
    animate("на этого бота я потратил много времени и видимо не зря.", delay=0.001, color="37")
    animate("этот проэкт был создан создателем канала по роблокс скрпитам читам:", delay=0.001, color="37")
    animate("https://t.me/vomagla", delay=0.002, color="33")
    animate("бот был создан потомучто чат этого канала накрутили ботами.", delay=0.001, color="37")
    animate("пока!!", delay=0.002, color="37")
    print()
    print()
    header("ДАЛЬШЕ", "35")
    animate("1. Продолжить (начать заново с выбора чата)", delay=0.001, color="37")
    animate("2. Удалить файл с данными для автологина и начать всё заново", delay=0.001, color="37")
    animate("3. Выйти", delay=0.001, color="37")
    print()
    while True:
        fc = (await asyncio.to_thread(input, "Твой выбор: ")).strip()
        if fc in ["1", "2", "3"]:
            break
        print("\x1b[31mНеверный выбор. Введи 1, 2 или 3.\x1b[0m")

    if fc == "2":
        # Delete session + creds file → full restart from scratch
        try: await client.disconnect()
        except: pass
        try:
            if os.path.exists(SESSION_FILE):
                os.remove(SESSION_FILE)
            creds_file = SCRIPT_DIR / ".last_creds"
            if creds_file.exists():
                creds_file.unlink()
        except: pass
        animate("Файлы удалены. Перезапускаю...", delay=0.001, color="33")
        await main_async()
        return
    elif fc.strip() == "3":
        try: await client.disconnect()
        except: pass
        return
    else:
        # Option 1: continue (restart with session preserved)
        try: await client.disconnect()
        except: pass
        print("Перезапускаю...")
        await main_async()
        return


def main():
    while True:
        try:
            asyncio.run(main_async())
            break
        except KeyboardInterrupt:
            # Check if user pressed P to restart
            import traceback
            tb = traceback.format_exc()
            if "USER_PRESSED_P" in tb:
                print("\nПерезапускаю с начала...")
                continue
            print("\nBye.")
            break
        except Exception as e:
            print(f"\nПроизошла ошибка: {e}")
            try:
                input("Нажми Enter, чтобы попробовать снова...")
            except (EOFError, KeyboardInterrupt):
                break
            # Loop back and re-run main()


if __name__ == "__main__":
    main()